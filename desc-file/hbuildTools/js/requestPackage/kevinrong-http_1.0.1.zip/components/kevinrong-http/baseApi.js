const BaseApi = 'https://www.baidu.com'

export {
	BaseApi
}
