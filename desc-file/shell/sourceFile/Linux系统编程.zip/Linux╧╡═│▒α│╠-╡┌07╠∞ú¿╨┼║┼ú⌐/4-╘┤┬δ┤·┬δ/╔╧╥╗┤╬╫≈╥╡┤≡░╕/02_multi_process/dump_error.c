#include <stdio.h>
#include <string.h>


int main()
{
    char *p = NULL;
	strcpy(p, "hello mike");

    return 0;
}
