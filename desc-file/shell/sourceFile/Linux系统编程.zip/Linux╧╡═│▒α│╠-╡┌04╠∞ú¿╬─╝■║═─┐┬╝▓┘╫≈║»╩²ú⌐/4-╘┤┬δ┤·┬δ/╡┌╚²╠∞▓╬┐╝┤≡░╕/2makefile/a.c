#include <stdio.h>

int main(void)
{
    printf("hello world a....\n");

    return 0;
}
