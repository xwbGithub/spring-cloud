#include <stdio.h>

int main(void)
{
    printf("hello world b....\n");

    return 0;
}
