#include "div.h"


int div(int x, int y)
{
    return x / y;
}

