#ifndef __DIV_H__
#define __DIV_H__

int div(int x, int y);

#endif /*__DIV_H__*/



