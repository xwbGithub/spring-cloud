#include <stdio.h>

int main(void)
{
    printf("hello file\n");

    return -1;  //0 --255  寄存器8位 无符号
}
