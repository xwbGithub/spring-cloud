#ifndef __ADD_H__
#define __ADD_H__

int add(int x, int y);


#endif /*__ADD_H__*/
