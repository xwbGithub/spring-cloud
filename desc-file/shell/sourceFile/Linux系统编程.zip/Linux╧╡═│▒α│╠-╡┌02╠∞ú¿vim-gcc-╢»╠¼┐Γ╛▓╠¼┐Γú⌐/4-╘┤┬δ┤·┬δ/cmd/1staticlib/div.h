#ifndef __DIV_H__
#define __DIV_H__

int mydiv(int x, int y);


#endif /*__DIV_H__*/
