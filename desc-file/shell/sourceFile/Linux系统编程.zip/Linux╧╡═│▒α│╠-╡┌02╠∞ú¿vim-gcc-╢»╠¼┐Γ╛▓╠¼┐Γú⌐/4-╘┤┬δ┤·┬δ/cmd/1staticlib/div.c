#include "div.h"

int mydiv(int x, int y)
{
    return x / y;
}
