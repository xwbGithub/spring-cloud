#ifndef __MUL_H__
#define __MUL_H__

int mul(int x, int y);


#endif /*__MUL_H__*/
