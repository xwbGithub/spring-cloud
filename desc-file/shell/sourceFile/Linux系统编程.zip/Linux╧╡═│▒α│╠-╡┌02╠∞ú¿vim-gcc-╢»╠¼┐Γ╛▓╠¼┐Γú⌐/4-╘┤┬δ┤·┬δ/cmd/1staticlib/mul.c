#include "mul.h"

int mul(int x, int y)
{
    return x * y;
}
