#include <stdio.h>
#include <string.h> 
#include <stdlib.h> 

int main(void)
{
    //int a = 3;
    
    //printf("SIZE: %d\n", SIZE);
    printf("hello world\n");

    return 0;
}
