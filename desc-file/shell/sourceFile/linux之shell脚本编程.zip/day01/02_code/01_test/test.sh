#!/bin/sh
echo HelloWorld
cd ..
ls
