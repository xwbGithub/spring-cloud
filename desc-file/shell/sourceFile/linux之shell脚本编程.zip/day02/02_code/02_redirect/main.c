#include <stdio.h>
int main()
{
    fprintf(stdout,"This is stdout\n");
    fprintf(stderr,"This is stderr\n");
    return 0;
}
